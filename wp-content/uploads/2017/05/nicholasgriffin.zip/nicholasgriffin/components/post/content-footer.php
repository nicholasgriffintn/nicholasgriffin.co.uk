	<footer class="entry-footer">
		<?php nicholasgriffin_entry_footer(); ?>
	</footer><!-- .entry-footer -->