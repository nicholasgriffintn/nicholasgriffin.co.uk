		<div class="entry-meta">
			<?php nicholasgriffin_posted_on(); ?>
		</div><!-- .entry-meta -->